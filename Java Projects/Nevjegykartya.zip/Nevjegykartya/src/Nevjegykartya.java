
public class Nevjegykartya {
    public static void main(String[] args) {
        String horizontalLine = "---*---*------------------------------*------------------------------*---*---";

        String name =           "   | Name: Koics Marcell                                             |";
        String age =            "   | Age: 25                                                         |";
        String email =          "   | E-mail: marcell.koics@gmail.com                                 |";
        String phone =          "   | Phone: +36705555928                                             |";
        String facebook =       "   | Facebook: https://www.facebook.com/koics.marcell/               |";
        String github =         "   | GitHub: https://github.com/koics97                              |";

        System.out.println(horizontalLine);
        System.out.println(name);
        System.out.println(horizontalLine);
        System.out.println(age);
        System.out.println(horizontalLine);
        System.out.println(email);
        System.out.println(horizontalLine);
        System.out.println(phone);
        System.out.println(horizontalLine);
        System.out.println(facebook);
        System.out.println(horizontalLine);
        System.out.println(github);
        System.out.println(horizontalLine);

    }
}

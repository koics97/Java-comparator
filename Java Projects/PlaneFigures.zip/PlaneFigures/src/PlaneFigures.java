public class PlaneFigures {
    public static void main(String[] args) {
        System.out.println("negyzet:");
        System.out.println("**********");
        System.out.println("**********");
        System.out.println("**********");
        System.out.println("**********");

        System.out.println();

        System.out.println("teglalap:");
        System.out.println("*****************");
        System.out.println("*****************");
        System.out.println("*****************");
        System.out.println("*****************");

        System.out.println();

        System.out.println("paralelogramma:");
        System.out.println("    *****************");
        System.out.println("   *****************");
        System.out.println("  *****************");
        System.out.println(" *****************");

        System.out.println();

        System.out.println("trapez:");
        System.out.println("     **********     ");
        System.out.println("    ************   ");
        System.out.println("   **************   ");
        System.out.println("  ****************  ");
        System.out.println(" ****************** ");
        System.out.println("********************");

        System.out.println();

        System.out.println("rombusz:");
        System.out.println("          *          ");
        System.out.println("        *****        ");
        System.out.println("      *********      ");
        System.out.println("    *************    ");
        System.out.println("      *********      ");
        System.out.println("        *****        ");
        System.out.println("          *          ");

        System.out.println();

        System.out.println("deltoid:");
        System.out.println("          *          ");
        System.out.println("      *********     ");
        System.out.println("   ***************   ");
        System.out.println("*********************");
        System.out.println(" ******************* ");
        System.out.println("  *****************  ");
        System.out.println("   ***************   ");
        System.out.println("    *************    ");
        System.out.println("     ***********     ");
        System.out.println("      *********      ");
        System.out.println("       *******       ");
        System.out.println("        *****        ");
        System.out.println("         ***         ");
        System.out.println("          *          ");

        System.out.println();

        System.out.println("haromszog:");
        System.out.println("        *        ");
        System.out.println("      *****      ");
        System.out.println("    *********    ");
        System.out.println("  *************  ");
        System.out.println("*****************");
    }
}
